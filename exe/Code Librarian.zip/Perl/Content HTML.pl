print "Content-Type: text/html\n\n";
